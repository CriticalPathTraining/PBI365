﻿var x = {
  "name": "Campaign Donations DB",
  "tables": [
    {
      "name": "Donations",
      "columns": [
        {
          "name": "Id",
          "dataType": "Int64"
        },
        {
          "name": "Name",
          "dataType": "string"
        }

      ]
    }
  ]
}